/*++ BUILD Version: 0001    // Increment this if a change has global effects

Copyright (c) 1991  Microsoft Corporation

Module Name:

    bugcodes.mc

Abstract:

    This module contains the definition of the system bug check codes.

Notes:

    No message strings should be added to the bugcodes' entries. Their
    symbolic names take the place of message strings.

--*/

#ifndef _BUGCODES_
#define _BUGCODES_


//
//  Values are 32 bit values laid out as follows:
//
//   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
//   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
//  +---+-+-+-----------------------+-------------------------------+
//  |Sev|C|R|     Facility          |               Code            |
//  +---+-+-+-----------------------+-------------------------------+
//
//  where
//
//      Sev - is the severity code
//
//          00 - Success
//          01 - Informational
//          10 - Warning
//          11 - Error
//
//      C - is the Customer code flag
//
//      R - is a reserved bit
//
//      Facility - is the facility code
//
//      Code - is the facility's status code
//
//
// Define the facility codes
//


//
// Define the severity codes
//


//
// MessageId: HARDWARE_PROFILE_UNDOCKED_STRING
//
// MessageText:
//
// Undocked Profile
//
#define HARDWARE_PROFILE_UNDOCKED_STRING ((ULONG)0x40010001L)

//
// MessageId: HARDWARE_PROFILE_DOCKED_STRING
//
// MessageText:
//
// Docked Profile
//
#define HARDWARE_PROFILE_DOCKED_STRING   ((ULONG)0x40010002L)

//
// MessageId: HARDWARE_PROFILE_UNKNOWN_STRING
//
// MessageText:
//
// Profile
//
#define HARDWARE_PROFILE_UNKNOWN_STRING  ((ULONG)0x40010003L)

//
// MessageId: WINDOWS_NT_BANNER
//
// MessageText:
//
// Microsoft (R) Windows (R) Version %hs (Build %u%hs)
//
#define WINDOWS_NT_BANNER                ((ULONG)0x4000007EL)

//
// MessageId: WINDOWS_NT_CSD_STRING
//
// MessageText:
//
// Service Pack
//
#define WINDOWS_NT_CSD_STRING            ((ULONG)0x40000087L)

//
// MessageId: WINDOWS_NT_INFO_STRING
//
// MessageText:
//
// %u System Processor [%u MB Memory] %Z
//
#define WINDOWS_NT_INFO_STRING           ((ULONG)0x40000088L)

//
// MessageId: WINDOWS_NT_MP_STRING
//
// MessageText:
//
// MultiProcessor Kernel
//
#define WINDOWS_NT_MP_STRING             ((ULONG)0x40000089L)

//
// MessageId: THREAD_TERMINATE_HELD_MUTEX
//
// MessageText:
//
// A kernel thread terminated while holding a mutex
//
#define THREAD_TERMINATE_HELD_MUTEX      ((ULONG)0x4000008AL)

//
// MessageId: WINDOWS_NT_INFO_STRING_PLURAL
//
// MessageText:
//
// %u System Processors [%u MB Memory] %Z
//
#define WINDOWS_NT_INFO_STRING_PLURAL    ((ULONG)0x4000009DL)

//
// MessageId: WINDOWS_NT_RC_STRING
//
// MessageText:
//
// RC
//
#define WINDOWS_NT_RC_STRING             ((ULONG)0x4000009EL)

//
// MessageId: APC_INDEX_MISMATCH
//
// MessageText:
//
//  APC_INDEX_MISMATCH
//
#define APC_INDEX_MISMATCH               ((ULONG)0x00000001L)

//
// MessageId: DEVICE_QUEUE_NOT_BUSY
//
// MessageText:
//
//  DEVICE_QUEUE_NOT_BUSY
//
#define DEVICE_QUEUE_NOT_BUSY            ((ULONG)0x00000002L)

//
// MessageId: INVALID_AFFINITY_SET
//
// MessageText:
//
//  INVALID_AFFINITY_SET
//
#define INVALID_AFFINITY_SET             ((ULONG)0x00000003L)

//
// MessageId: INVALID_DATA_ACCESS_TRAP
//
// MessageText:
//
//  INVALID_DATA_ACCESS_TRAP
//
#define INVALID_DATA_ACCESS_TRAP         ((ULONG)0x00000004L)

//
// MessageId: INVALID_PROCESS_ATTACH_ATTEMPT
//
// MessageText:
//
//  INVALID_PROCESS_ATTACH_ATTEMPT
//
#define INVALID_PROCESS_ATTACH_ATTEMPT   ((ULONG)0x00000005L)

//
// MessageId: INVALID_PROCESS_DETACH_ATTEMPT
//
// MessageText:
//
//  INVALID_PROCESS_DETACH_ATTEMPT
//
#define INVALID_PROCESS_DETACH_ATTEMPT   ((ULONG)0x00000006L)

//
// MessageId: INVALID_SOFTWARE_INTERRUPT
//
// MessageText:
//
//  INVALID_SOFTWARE_INTERRUPT
//
#define INVALID_SOFTWARE_INTERRUPT       ((ULONG)0x00000007L)

//
// MessageId: IRQL_NOT_DISPATCH_LEVEL
//
// MessageText:
//
//  IRQL_NOT_DISPATCH_LEVEL
//
#define IRQL_NOT_DISPATCH_LEVEL          ((ULONG)0x00000008L)

//
// MessageId: IRQL_NOT_GREATER_OR_EQUAL
//
// MessageText:
//
//  IRQL_NOT_GREATER_OR_EQUAL
//
#define IRQL_NOT_GREATER_OR_EQUAL        ((ULONG)0x00000009L)

//
// MessageId: IRQL_NOT_LESS_OR_EQUAL
//
// MessageText:
//
//  IRQL_NOT_LESS_OR_EQUAL
//
#define IRQL_NOT_LESS_OR_EQUAL           ((ULONG)0x0000000AL)

//
// MessageId: NO_EXCEPTION_HANDLING_SUPPORT
//
// MessageText:
//
//  NO_EXCEPTION_HANDLING_SUPPORT
//
#define NO_EXCEPTION_HANDLING_SUPPORT    ((ULONG)0x0000000BL)

//
// MessageId: MAXIMUM_WAIT_OBJECTS_EXCEEDED
//
// MessageText:
//
//  MAXIMUM_WAIT_OBJECTS_EXCEEDED
//
#define MAXIMUM_WAIT_OBJECTS_EXCEEDED    ((ULONG)0x0000000CL)

//
// MessageId: MUTEX_LEVEL_NUMBER_VIOLATION
//
// MessageText:
//
//  MUTEX_LEVEL_NUMBER_VIOLATION
//
#define MUTEX_LEVEL_NUMBER_VIOLATION     ((ULONG)0x0000000DL)

//
// MessageId: NO_USER_MODE_CONTEXT
//
// MessageText:
//
//  NO_USER_MODE_CONTEXT
//
#define NO_USER_MODE_CONTEXT             ((ULONG)0x0000000EL)

//
// MessageId: SPIN_LOCK_ALREADY_OWNED
//
// MessageText:
//
//  SPIN_LOCK_ALREADY_OWNED
//
#define SPIN_LOCK_ALREADY_OWNED          ((ULONG)0x0000000FL)

//
// MessageId: SPIN_LOCK_NOT_OWNED
//
// MessageText:
//
//  SPIN_LOCK_NOT_OWNED
//
#define SPIN_LOCK_NOT_OWNED              ((ULONG)0x00000010L)

//
// MessageId: THREAD_NOT_MUTEX_OWNER
//
// MessageText:
//
//  THREAD_NOT_MUTEX_OWNER
//
#define THREAD_NOT_MUTEX_OWNER           ((ULONG)0x00000011L)

//
// MessageId: TRAP_CAUSE_UNKNOWN
//
// MessageText:
//
//  TRAP_CAUSE_UNKNOWN
//
#define TRAP_CAUSE_UNKNOWN               ((ULONG)0x00000012L)

//
// MessageId: EMPTY_THREAD_REAPER_LIST
//
// MessageText:
//
//  EMPTY_THREAD_REAPER_LIST
//
#define EMPTY_THREAD_REAPER_LIST         ((ULONG)0x00000013L)

//
// MessageId: CREATE_DELETE_LOCK_NOT_LOCKED
//
// MessageText:
//
//  CREATE_DELETE_LOCK_NOT_LOCKED
//
#define CREATE_DELETE_LOCK_NOT_LOCKED    ((ULONG)0x00000014L)

//
// MessageId: LAST_CHANCE_CALLED_FROM_KMODE
//
// MessageText:
//
//  LAST_CHANCE_CALLED_FROM_KMODE
//
#define LAST_CHANCE_CALLED_FROM_KMODE    ((ULONG)0x00000015L)

//
// MessageId: CID_HANDLE_CREATION
//
// MessageText:
//
//  CID_HANDLE_CREATION
//
#define CID_HANDLE_CREATION              ((ULONG)0x00000016L)

//
// MessageId: CID_HANDLE_DELETION
//
// MessageText:
//
//  CID_HANDLE_DELETION
//
#define CID_HANDLE_DELETION              ((ULONG)0x00000017L)

//
// MessageId: REFERENCE_BY_POINTER
//
// MessageText:
//
//  REFERENCE_BY_POINTER
//
#define REFERENCE_BY_POINTER             ((ULONG)0x00000018L)

//
// MessageId: BAD_POOL_HEADER
//
// MessageText:
//
//  BAD_POOL_HEADER
//
#define BAD_POOL_HEADER                  ((ULONG)0x00000019L)

//
// MessageId: MEMORY_MANAGEMENT
//
// MessageText:
//
//  MEMORY_MANAGEMENT
//
#define MEMORY_MANAGEMENT                ((ULONG)0x0000001AL)

//
// MessageId: PFN_SHARE_COUNT
//
// MessageText:
//
//  PFN_SHARE_COUNT
//
#define PFN_SHARE_COUNT                  ((ULONG)0x0000001BL)

//
// MessageId: PFN_REFERENCE_COUNT
//
// MessageText:
//
//  PFN_REFERENCE_COUNT
//
#define PFN_REFERENCE_COUNT              ((ULONG)0x0000001CL)

//
// MessageId: NO_SPIN_LOCK_AVAILABLE
//
// MessageText:
//
//  NO_SPIN_LOCK_AVAILABLE
//
#define NO_SPIN_LOCK_AVAILABLE           ((ULONG)0x0000001DL)

//
// MessageId: KMODE_EXCEPTION_NOT_HANDLED
//
// MessageText:
//
//  KMODE_EXCEPTION_NOT_HANDLED
//
#define KMODE_EXCEPTION_NOT_HANDLED      ((ULONG)0x0000001EL)

//
// MessageId: SHARED_RESOURCE_CONV_ERROR
//
// MessageText:
//
//  SHARED_RESOURCE_CONV_ERROR
//
#define SHARED_RESOURCE_CONV_ERROR       ((ULONG)0x0000001FL)

//
// MessageId: KERNEL_APC_PENDING_DURING_EXIT
//
// MessageText:
//
//  KERNEL_APC_PENDING_DURING_EXIT
//
#define KERNEL_APC_PENDING_DURING_EXIT   ((ULONG)0x00000020L)

//
// MessageId: QUOTA_UNDERFLOW
//
// MessageText:
//
//  QUOTA_UNDERFLOW
//
#define QUOTA_UNDERFLOW                  ((ULONG)0x00000021L)

//
// MessageId: FILE_SYSTEM
//
// MessageText:
//
//  FILE_SYSTEM
//
#define FILE_SYSTEM                      ((ULONG)0x00000022L)

//
// MessageId: FAT_FILE_SYSTEM
//
// MessageText:
//
//  FAT_FILE_SYSTEM
//
#define FAT_FILE_SYSTEM                  ((ULONG)0x00000023L)

//
// MessageId: NTFS_FILE_SYSTEM
//
// MessageText:
//
//  NTFS_FILE_SYSTEM
//
#define NTFS_FILE_SYSTEM                 ((ULONG)0x00000024L)

//
// MessageId: NPFS_FILE_SYSTEM
//
// MessageText:
//
//  NPFS_FILE_SYSTEM
//
#define NPFS_FILE_SYSTEM                 ((ULONG)0x00000025L)

//
// MessageId: CDFS_FILE_SYSTEM
//
// MessageText:
//
//  CDFS_FILE_SYSTEM
//
#define CDFS_FILE_SYSTEM                 ((ULONG)0x00000026L)

//
// MessageId: RDR_FILE_SYSTEM
//
// MessageText:
//
//  RDR_FILE_SYSTEM
//
#define RDR_FILE_SYSTEM                  ((ULONG)0x00000027L)

//
// MessageId: CORRUPT_ACCESS_TOKEN
//
// MessageText:
//
//  CORRUPT_ACCESS_TOKEN
//
#define CORRUPT_ACCESS_TOKEN             ((ULONG)0x00000028L)

//
// MessageId: SECURITY_SYSTEM
//
// MessageText:
//
//  SECURITY_SYSTEM
//
#define SECURITY_SYSTEM                  ((ULONG)0x00000029L)

//
// MessageId: INCONSISTENT_IRP
//
// MessageText:
//
//  INCONSISTENT_IRP
//
#define INCONSISTENT_IRP                 ((ULONG)0x0000002AL)

//
// MessageId: PANIC_STACK_SWITCH
//
// MessageText:
//
//  PANIC_STACK_SWITCH
//
#define PANIC_STACK_SWITCH               ((ULONG)0x0000002BL)

//
// MessageId: PORT_DRIVER_INTERNAL
//
// MessageText:
//
//  PORT_DRIVER_INTERNAL
//
#define PORT_DRIVER_INTERNAL             ((ULONG)0x0000002CL)

//
// MessageId: SCSI_DISK_DRIVER_INTERNAL
//
// MessageText:
//
//  SCSI_DISK_DRIVER_INTERNAL
//
#define SCSI_DISK_DRIVER_INTERNAL        ((ULONG)0x0000002DL)

//
// MessageId: DATA_BUS_ERROR
//
// MessageText:
//
//  DATA_BUS_ERROR
//
#define DATA_BUS_ERROR                   ((ULONG)0x0000002EL)

//
// MessageId: INSTRUCTION_BUS_ERROR
//
// MessageText:
//
//  INSTRUCTION_BUS_ERROR
//
#define INSTRUCTION_BUS_ERROR            ((ULONG)0x0000002FL)

//
// MessageId: SET_OF_INVALID_CONTEXT
//
// MessageText:
//
//  SET_OF_INVALID_CONTEXT
//
#define SET_OF_INVALID_CONTEXT           ((ULONG)0x00000030L)

//
// MessageId: PHASE0_INITIALIZATION_FAILED
//
// MessageText:
//
//  PHASE0_INITIALIZATION_FAILED
//
#define PHASE0_INITIALIZATION_FAILED     ((ULONG)0x00000031L)

//
// MessageId: PHASE1_INITIALIZATION_FAILED
//
// MessageText:
//
//  PHASE1_INITIALIZATION_FAILED
//
#define PHASE1_INITIALIZATION_FAILED     ((ULONG)0x00000032L)

//
// MessageId: UNEXPECTED_INITIALIZATION_CALL
//
// MessageText:
//
//  UNEXPECTED_INITIALIZATION_CALL
//
#define UNEXPECTED_INITIALIZATION_CALL   ((ULONG)0x00000033L)

//
// MessageId: CACHE_MANAGER
//
// MessageText:
//
//  CACHE_MANAGER
//
#define CACHE_MANAGER                    ((ULONG)0x00000034L)

//
// MessageId: NO_MORE_IRP_STACK_LOCATIONS
//
// MessageText:
//
//  NO_MORE_IRP_STACK_LOCATIONS
//
#define NO_MORE_IRP_STACK_LOCATIONS      ((ULONG)0x00000035L)

//
// MessageId: DEVICE_REFERENCE_COUNT_NOT_ZERO
//
// MessageText:
//
//  DEVICE_REFERENCE_COUNT_NOT_ZERO
//
#define DEVICE_REFERENCE_COUNT_NOT_ZERO  ((ULONG)0x00000036L)

//
// MessageId: FLOPPY_INTERNAL_ERROR
//
// MessageText:
//
//  FLOPPY_INTERNAL_ERROR
//
#define FLOPPY_INTERNAL_ERROR            ((ULONG)0x00000037L)

//
// MessageId: SERIAL_DRIVER_INTERNAL
//
// MessageText:
//
//  SERIAL_DRIVER_INTERNAL
//
#define SERIAL_DRIVER_INTERNAL           ((ULONG)0x00000038L)

//
// MessageId: SYSTEM_EXIT_OWNED_MUTEX
//
// MessageText:
//
//  SYSTEM_EXIT_OWNED_MUTEX
//
#define SYSTEM_EXIT_OWNED_MUTEX          ((ULONG)0x00000039L)

//
// MessageId: SYSTEM_UNWIND_PREVIOUS_USER
//
// MessageText:
//
//  SYSTEM_UNWIND_PREVIOUS_USER
//
#define SYSTEM_UNWIND_PREVIOUS_USER      ((ULONG)0x0000003AL)

//
// MessageId: SYSTEM_SERVICE_EXCEPTION
//
// MessageText:
//
//  SYSTEM_SERVICE_EXCEPTION
//
#define SYSTEM_SERVICE_EXCEPTION         ((ULONG)0x0000003BL)

//
// MessageId: INTERRUPT_UNWIND_ATTEMPTED
//
// MessageText:
//
//  INTERRUPT_UNWIND_ATTEMPTED
//
#define INTERRUPT_UNWIND_ATTEMPTED       ((ULONG)0x0000003CL)

//
// MessageId: INTERRUPT_EXCEPTION_NOT_HANDLED
//
// MessageText:
//
//  INTERRUPT_EXCEPTION_NOT_HANDLED
//
#define INTERRUPT_EXCEPTION_NOT_HANDLED  ((ULONG)0x0000003DL)

//
// MessageId: MULTIPROCESSOR_CONFIGURATION_NOT_SUPPORTED
//
// MessageText:
//
//  MULTIPROCESSOR_CONFIGURATION_NOT_SUPPORTED
//
#define MULTIPROCESSOR_CONFIGURATION_NOT_SUPPORTED ((ULONG)0x0000003EL)

//
// MessageId: NO_MORE_SYSTEM_PTES
//
// MessageText:
//
//  NO_MORE_SYSTEM_PTES
//
#define NO_MORE_SYSTEM_PTES              ((ULONG)0x0000003FL)

//
// MessageId: TARGET_MDL_TOO_SMALL
//
// MessageText:
//
//  TARGET_MDL_TOO_SMALL
//
#define TARGET_MDL_TOO_SMALL             ((ULONG)0x00000040L)

//
// MessageId: MUST_SUCCEED_POOL_EMPTY
//
// MessageText:
//
//  MUST_SUCCEED_POOL_EMPTY
//
#define MUST_SUCCEED_POOL_EMPTY          ((ULONG)0x00000041L)

//
// MessageId: ATDISK_DRIVER_INTERNAL
//
// MessageText:
//
//  ATDISK_DRIVER_INTERNAL
//
#define ATDISK_DRIVER_INTERNAL           ((ULONG)0x00000042L)

//
// MessageId: NO_SUCH_PARTITION
//
// MessageText:
//
//  NO_SUCH_PARTITION
//
#define NO_SUCH_PARTITION                ((ULONG)0x00000043L)

//
// MessageId: MULTIPLE_IRP_COMPLETE_REQUESTS
//
// MessageText:
//
//  MULTIPLE_IRP_COMPLETE_REQUESTS
//
#define MULTIPLE_IRP_COMPLETE_REQUESTS   ((ULONG)0x00000044L)

//
// MessageId: INSUFFICIENT_SYSTEM_MAP_REGS
//
// MessageText:
//
//  INSUFFICIENT_SYSTEM_MAP_REGS
//
#define INSUFFICIENT_SYSTEM_MAP_REGS     ((ULONG)0x00000045L)

//
// MessageId: DEREF_UNKNOWN_LOGON_SESSION
//
// MessageText:
//
//  DEREF_UNKNOWN_LOGON_SESSION
//
#define DEREF_UNKNOWN_LOGON_SESSION      ((ULONG)0x00000046L)

//
// MessageId: REF_UNKNOWN_LOGON_SESSION
//
// MessageText:
//
//  REF_UNKNOWN_LOGON_SESSION
//
#define REF_UNKNOWN_LOGON_SESSION        ((ULONG)0x00000047L)

//
// MessageId: CANCEL_STATE_IN_COMPLETED_IRP
//
// MessageText:
//
//  CANCEL_STATE_IN_COMPLETED_IRP
//
#define CANCEL_STATE_IN_COMPLETED_IRP    ((ULONG)0x00000048L)

//
// MessageId: PAGE_FAULT_WITH_INTERRUPTS_OFF
//
// MessageText:
//
//  PAGE_FAULT_WITH_INTERRUPTS_OFF
//
#define PAGE_FAULT_WITH_INTERRUPTS_OFF   ((ULONG)0x00000049L)

//
// MessageId: IRQL_GT_ZERO_AT_SYSTEM_SERVICE
//
// MessageText:
//
//  IRQL_GT_ZERO_AT_SYSTEM_SERVICE
//
#define IRQL_GT_ZERO_AT_SYSTEM_SERVICE   ((ULONG)0x0000004AL)

//
// MessageId: STREAMS_INTERNAL_ERROR
//
// MessageText:
//
//  STREAMS_INTERNAL_ERROR
//
#define STREAMS_INTERNAL_ERROR           ((ULONG)0x0000004BL)

//
// MessageId: FATAL_UNHANDLED_HARD_ERROR
//
// MessageText:
//
//  FATAL_UNHANDLED_HARD_ERROR
//
#define FATAL_UNHANDLED_HARD_ERROR       ((ULONG)0x0000004CL)

//
// MessageId: NO_PAGES_AVAILABLE
//
// MessageText:
//
//  NO_PAGES_AVAILABLE
//
#define NO_PAGES_AVAILABLE               ((ULONG)0x0000004DL)

//
// MessageId: PFN_LIST_CORRUPT
//
// MessageText:
//
//  PFN_LIST_CORRUPT
//
#define PFN_LIST_CORRUPT                 ((ULONG)0x0000004EL)

//
// MessageId: NDIS_INTERNAL_ERROR
//
// MessageText:
//
//  NDIS_INTERNAL_ERROR
//
#define NDIS_INTERNAL_ERROR              ((ULONG)0x0000004FL)

//
// MessageId: PAGE_FAULT_IN_NONPAGED_AREA
//
// MessageText:
//
//  PAGE_FAULT_IN_NONPAGED_AREA
//
#define PAGE_FAULT_IN_NONPAGED_AREA      ((ULONG)0x00000050L)

#define PAGE_FAULT_IN_NONPAGED_AREA_M ((ULONG)0x10000050L)
//
// MessageId: REGISTRY_ERROR
//
// MessageText:
//
//  REGISTRY_ERROR
//
#define REGISTRY_ERROR                   ((ULONG)0x00000051L)

//
// MessageId: MAILSLOT_FILE_SYSTEM
//
// MessageText:
//
//  MAILSLOT_FILE_SYSTEM
//
#define MAILSLOT_FILE_SYSTEM             ((ULONG)0x00000052L)

//
// MessageId: NO_BOOT_DEVICE
//
// MessageText:
//
//  NO_BOOT_DEVICE
//
#define NO_BOOT_DEVICE                   ((ULONG)0x00000053L)

//
// MessageId: LM_SERVER_INTERNAL_ERROR
//
// MessageText:
//
//  LM_SERVER_INTERNAL_ERROR
//
#define LM_SERVER_INTERNAL_ERROR         ((ULONG)0x00000054L)

//
// MessageId: DATA_COHERENCY_EXCEPTION
//
// MessageText:
//
//  DATA_COHERENCY_EXCEPTION
//
#define DATA_COHERENCY_EXCEPTION         ((ULONG)0x00000055L)

//
// MessageId: INSTRUCTION_COHERENCY_EXCEPTION
//
// MessageText:
//
//  INSTRUCTION_COHERENCY_EXCEPTION
//
#define INSTRUCTION_COHERENCY_EXCEPTION  ((ULONG)0x00000056L)

//
// MessageId: XNS_INTERNAL_ERROR
//
// MessageText:
//
//  XNS_INTERNAL_ERROR
//
#define XNS_INTERNAL_ERROR               ((ULONG)0x00000057L)

//
// MessageId: VOLMGRX_INTERNAL_ERROR
//
// MessageText:
//
//  VOLMGRX_INTERNAL_ERROR
//
#define VOLMGRX_INTERNAL_ERROR           ((ULONG)0x00000058L)

//
// MessageId: PINBALL_FILE_SYSTEM
//
// MessageText:
//
//  PINBALL_FILE_SYSTEM
//
#define PINBALL_FILE_SYSTEM              ((ULONG)0x00000059L)

//
// MessageId: CRITICAL_SERVICE_FAILED
//
// MessageText:
//
//  CRITICAL_SERVICE_FAILED
//
#define CRITICAL_SERVICE_FAILED          ((ULONG)0x0000005AL)

//
// MessageId: SET_ENV_VAR_FAILED
//
// MessageText:
//
//  SET_ENV_VAR_FAILED
//
#define SET_ENV_VAR_FAILED               ((ULONG)0x0000005BL)

//
// MessageId: HAL_INITIALIZATION_FAILED
//
// MessageText:
//
//  HAL_INITIALIZATION_FAILED
//
#define HAL_INITIALIZATION_FAILED        ((ULONG)0x0000005CL)

//
// MessageId: UNSUPPORTED_PROCESSOR
//
// MessageText:
//
//  UNSUPPORTED_PROCESSOR
//
#define UNSUPPORTED_PROCESSOR            ((ULONG)0x0000005DL)

//
// MessageId: OBJECT_INITIALIZATION_FAILED
//
// MessageText:
//
//  OBJECT_INITIALIZATION_FAILED
//
#define OBJECT_INITIALIZATION_FAILED     ((ULONG)0x0000005EL)

//
// MessageId: SECURITY_INITIALIZATION_FAILED
//
// MessageText:
//
//  SECURITY_INITIALIZATION_FAILED
//
#define SECURITY_INITIALIZATION_FAILED   ((ULONG)0x0000005FL)

//
// MessageId: PROCESS_INITIALIZATION_FAILED
//
// MessageText:
//
//  PROCESS_INITIALIZATION_FAILED
//
#define PROCESS_INITIALIZATION_FAILED    ((ULONG)0x00000060L)

//
// MessageId: HAL1_INITIALIZATION_FAILED
//
// MessageText:
//
//  HAL1_INITIALIZATION_FAILED
//
#define HAL1_INITIALIZATION_FAILED       ((ULONG)0x00000061L)

//
// MessageId: OBJECT1_INITIALIZATION_FAILED
//
// MessageText:
//
//  OBJECT1_INITIALIZATION_FAILED
//
#define OBJECT1_INITIALIZATION_FAILED    ((ULONG)0x00000062L)

//
// MessageId: SECURITY1_INITIALIZATION_FAILED
//
// MessageText:
//
//  SECURITY1_INITIALIZATION_FAILED
//
#define SECURITY1_INITIALIZATION_FAILED  ((ULONG)0x00000063L)

//
// MessageId: SYMBOLIC_INITIALIZATION_FAILED
//
// MessageText:
//
//  SYMBOLIC_INITIALIZATION_FAILED
//
#define SYMBOLIC_INITIALIZATION_FAILED   ((ULONG)0x00000064L)

//
// MessageId: MEMORY1_INITIALIZATION_FAILED
//
// MessageText:
//
//  MEMORY1_INITIALIZATION_FAILED
//
#define MEMORY1_INITIALIZATION_FAILED    ((ULONG)0x00000065L)

//
// MessageId: CACHE_INITIALIZATION_FAILED
//
// MessageText:
//
//  CACHE_INITIALIZATION_FAILED
//
#define CACHE_INITIALIZATION_FAILED      ((ULONG)0x00000066L)

//
// MessageId: CONFIG_INITIALIZATION_FAILED
//
// MessageText:
//
//  CONFIG_INITIALIZATION_FAILED
//
#define CONFIG_INITIALIZATION_FAILED     ((ULONG)0x00000067L)

//
// MessageId: FILE_INITIALIZATION_FAILED
//
// MessageText:
//
//  FILE_INITIALIZATION_FAILED
//
#define FILE_INITIALIZATION_FAILED       ((ULONG)0x00000068L)

//
// MessageId: IO1_INITIALIZATION_FAILED
//
// MessageText:
//
//  IO1_INITIALIZATION_FAILED
//
#define IO1_INITIALIZATION_FAILED        ((ULONG)0x00000069L)

//
// MessageId: LPC_INITIALIZATION_FAILED
//
// MessageText:
//
//  LPC_INITIALIZATION_FAILED
//
#define LPC_INITIALIZATION_FAILED        ((ULONG)0x0000006AL)

//
// MessageId: PROCESS1_INITIALIZATION_FAILED
//
// MessageText:
//
//  PROCESS1_INITIALIZATION_FAILED
//
#define PROCESS1_INITIALIZATION_FAILED   ((ULONG)0x0000006BL)

//
// MessageId: REFMON_INITIALIZATION_FAILED
//
// MessageText:
//
//  REFMON_INITIALIZATION_FAILED
//
#define REFMON_INITIALIZATION_FAILED     ((ULONG)0x0000006CL)

//
// MessageId: SESSION1_INITIALIZATION_FAILED
//
// MessageText:
//
//  SESSION1_INITIALIZATION_FAILED
//
#define SESSION1_INITIALIZATION_FAILED   ((ULONG)0x0000006DL)

//
// MessageId: SESSION2_INITIALIZATION_FAILED
//
// MessageText:
//
//  SESSION2_INITIALIZATION_FAILED
//
#define SESSION2_INITIALIZATION_FAILED   ((ULONG)0x0000006EL)

//
// MessageId: SESSION3_INITIALIZATION_FAILED
//
// MessageText:
//
//  SESSION3_INITIALIZATION_FAILED
//
#define SESSION3_INITIALIZATION_FAILED   ((ULONG)0x0000006FL)

//
// MessageId: SESSION4_INITIALIZATION_FAILED
//
// MessageText:
//
//  SESSION4_INITIALIZATION_FAILED
//
#define SESSION4_INITIALIZATION_FAILED   ((ULONG)0x00000070L)

//
// MessageId: SESSION5_INITIALIZATION_FAILED
//
// MessageText:
//
//  SESSION5_INITIALIZATION_FAILED
//
#define SESSION5_INITIALIZATION_FAILED   ((ULONG)0x00000071L)

//
// MessageId: ASSIGN_DRIVE_LETTERS_FAILED
//
// MessageText:
//
//  ASSIGN_DRIVE_LETTERS_FAILED
//
#define ASSIGN_DRIVE_LETTERS_FAILED      ((ULONG)0x00000072L)

//
// MessageId: CONFIG_LIST_FAILED
//
// MessageText:
//
//  CONFIG_LIST_FAILED
//
#define CONFIG_LIST_FAILED               ((ULONG)0x00000073L)

//
// MessageId: BAD_SYSTEM_CONFIG_INFO
//
// MessageText:
//
//  BAD_SYSTEM_CONFIG_INFO
//
#define BAD_SYSTEM_CONFIG_INFO           ((ULONG)0x00000074L)

//
// MessageId: CANNOT_WRITE_CONFIGURATION
//
// MessageText:
//
//  CANNOT_WRITE_CONFIGURATION
//
#define CANNOT_WRITE_CONFIGURATION       ((ULONG)0x00000075L)

//
// MessageId: PROCESS_HAS_LOCKED_PAGES
//
// MessageText:
//
//  PROCESS_HAS_LOCKED_PAGES
//
#define PROCESS_HAS_LOCKED_PAGES         ((ULONG)0x00000076L)

//
// MessageId: KERNEL_STACK_INPAGE_ERROR
//
// MessageText:
//
//  KERNEL_STACK_INPAGE_ERROR
//
#define KERNEL_STACK_INPAGE_ERROR        ((ULONG)0x00000077L)

//
// MessageId: PHASE0_EXCEPTION
//
// MessageText:
//
//  PHASE0_EXCEPTION
//
#define PHASE0_EXCEPTION                 ((ULONG)0x00000078L)

//
// MessageId: MISMATCHED_HAL
//
// MessageText:
//
//  MISMATCHED_HAL
//
#define MISMATCHED_HAL                   ((ULONG)0x00000079L)

//
// MessageId: KERNEL_DATA_INPAGE_ERROR
//
// MessageText:
//
//  KERNEL_DATA_INPAGE_ERROR
//
#define KERNEL_DATA_INPAGE_ERROR         ((ULONG)0x0000007AL)

//
// MessageId: INACCESSIBLE_BOOT_DEVICE
//
// MessageText:
//
//  INACCESSIBLE_BOOT_DEVICE
//
#define INACCESSIBLE_BOOT_DEVICE         ((ULONG)0x0000007BL)

//
// MessageId: BUGCODE_NDIS_DRIVER
//
// MessageText:
//
//  BUGCODE_NDIS_DRIVER
//
#define BUGCODE_NDIS_DRIVER              ((ULONG)0x0000007CL)

//
// MessageId: INSTALL_MORE_MEMORY
//
// MessageText:
//
//  INSTALL_MORE_MEMORY
//
#define INSTALL_MORE_MEMORY              ((ULONG)0x0000007DL)

//
// MessageId: SYSTEM_THREAD_EXCEPTION_NOT_HANDLED
//
// MessageText:
//
//  SYSTEM_THREAD_EXCEPTION_NOT_HANDLED
//
#define SYSTEM_THREAD_EXCEPTION_NOT_HANDLED ((ULONG)0x0000007EL)

#define SYSTEM_THREAD_EXCEPTION_NOT_HANDLED_M ((ULONG)0x1000007EL)
//
// MessageId: UNEXPECTED_KERNEL_MODE_TRAP
//
// MessageText:
//
//  UNEXPECTED_KERNEL_MODE_TRAP
//
#define UNEXPECTED_KERNEL_MODE_TRAP      ((ULONG)0x0000007FL)

#define UNEXPECTED_KERNEL_MODE_TRAP_M ((ULONG)0x1000007FL)
//
// MessageId: NMI_HARDWARE_FAILURE
//
// MessageText:
//
//  NMI_HARDWARE_FAILURE
//
#define NMI_HARDWARE_FAILURE             ((ULONG)0x00000080L)

//
// MessageId: SPIN_LOCK_INIT_FAILURE
//
// MessageText:
//
//  SPIN_LOCK_INIT_FAILURE
//
#define SPIN_LOCK_INIT_FAILURE           ((ULONG)0x00000081L)

//
// MessageId: DFS_FILE_SYSTEM
//
// MessageText:
//
//  DFS_FILE_SYSTEM
//
#define DFS_FILE_SYSTEM                  ((ULONG)0x00000082L)

//
// MessageId: OFS_FILE_SYSTEM
//
// MessageText:
//
//  OFS_FILE_SYSTEM
//
#define OFS_FILE_SYSTEM                  ((ULONG)0x00000083L)

//
// MessageId: RECOM_DRIVER
//
// MessageText:
//
//  RECOM_DRIVER
//
#define RECOM_DRIVER                     ((ULONG)0x00000084L)

//
// MessageId: SETUP_FAILURE
//
// MessageText:
//
//  SETUP_FAILURE
//
#define SETUP_FAILURE                    ((ULONG)0x00000085L)

//
// MessageId: AUDIT_FAILURE
//
// MessageText:
//
//  AUDIT_FAILURE
//
#define AUDIT_FAILURE                    ((ULONG)0x00000086L)

//
// MessageId: MBR_CHECKSUM_MISMATCH
//
// MessageText:
//
//  MBR_CHECKSUM_MISMATCH
//
#define MBR_CHECKSUM_MISMATCH            ((ULONG)0x0000008BL)

//
// MessageId: KERNEL_MODE_EXCEPTION_NOT_HANDLED
//
// MessageText:
//
//  KERNEL_MODE_EXCEPTION_NOT_HANDLED
//
#define KERNEL_MODE_EXCEPTION_NOT_HANDLED ((ULONG)0x0000008EL)

#define KERNEL_MODE_EXCEPTION_NOT_HANDLED_M ((ULONG)0x1000008EL)
//
// MessageId: PP0_INITIALIZATION_FAILED
//
// MessageText:
//
//  PP0_INITIALIZATION_FAILED
//
#define PP0_INITIALIZATION_FAILED        ((ULONG)0x0000008FL)

//
// MessageId: PP1_INITIALIZATION_FAILED
//
// MessageText:
//
//  PP1_INITIALIZATION_FAILED
//
#define PP1_INITIALIZATION_FAILED        ((ULONG)0x00000090L)

//
// MessageId: WIN32K_INIT_OR_RIT_FAILURE
//
// MessageText:
//
//  WIN32K_INIT_OR_RIT_FAILURE
//
#define WIN32K_INIT_OR_RIT_FAILURE       ((ULONG)0x00000091L)

//
// MessageId: UP_DRIVER_ON_MP_SYSTEM
//
// MessageText:
//
//  UP_DRIVER_ON_MP_SYSTEM
//
#define UP_DRIVER_ON_MP_SYSTEM           ((ULONG)0x00000092L)

//
// MessageId: INVALID_KERNEL_HANDLE
//
// MessageText:
//
//  INVALID_KERNEL_HANDLE
//
#define INVALID_KERNEL_HANDLE            ((ULONG)0x00000093L)

//
// MessageId: KERNEL_STACK_LOCKED_AT_EXIT
//
// MessageText:
//
//  KERNEL_STACK_LOCKED_AT_EXIT
//
#define KERNEL_STACK_LOCKED_AT_EXIT      ((ULONG)0x00000094L)

//
// MessageId: PNP_INTERNAL_ERROR
//
// MessageText:
//
//  PNP_INTERNAL_ERROR
//
#define PNP_INTERNAL_ERROR               ((ULONG)0x00000095L)

//
// MessageId: INVALID_WORK_QUEUE_ITEM
//
// MessageText:
//
//  INVALID_WORK_QUEUE_ITEM
//
#define INVALID_WORK_QUEUE_ITEM          ((ULONG)0x00000096L)

//
// MessageId: BOUND_IMAGE_UNSUPPORTED
//
// MessageText:
//
//  BOUND_IMAGE_UNSUPPORTED
//
#define BOUND_IMAGE_UNSUPPORTED          ((ULONG)0x00000097L)

//
// MessageId: END_OF_NT_EVALUATION_PERIOD
//
// MessageText:
//
//  END_OF_NT_EVALUATION_PERIOD
//
#define END_OF_NT_EVALUATION_PERIOD      ((ULONG)0x00000098L)

//
// MessageId: INVALID_REGION_OR_SEGMENT
//
// MessageText:
//
//  INVALID_REGION_OR_SEGMENT
//
#define INVALID_REGION_OR_SEGMENT        ((ULONG)0x00000099L)

//
// MessageId: SYSTEM_LICENSE_VIOLATION
//
// MessageText:
//
//  SYSTEM_LICENSE_VIOLATION
//
#define SYSTEM_LICENSE_VIOLATION         ((ULONG)0x0000009AL)

//
// MessageId: UDFS_FILE_SYSTEM
//
// MessageText:
//
//  UDFS_FILE_SYSTEM
//
#define UDFS_FILE_SYSTEM                 ((ULONG)0x0000009BL)

//
// MessageId: MACHINE_CHECK_EXCEPTION
//
// MessageText:
//
//  MACHINE_CHECK_EXCEPTION
//
#define MACHINE_CHECK_EXCEPTION          ((ULONG)0x0000009CL)

//
// MessageId: USER_MODE_HEALTH_MONITOR
//
// MessageText:
//
//  USER_MODE_HEALTH_MONITOR
//
#define USER_MODE_HEALTH_MONITOR         ((ULONG)0x0000009EL)

//
// MessageId: DRIVER_POWER_STATE_FAILURE
//
// MessageText:
//
//  DRIVER_POWER_STATE_FAILURE
//
#define DRIVER_POWER_STATE_FAILURE       ((ULONG)0x0000009FL)

//
// MessageId: INTERNAL_POWER_ERROR
//
// MessageText:
//
//  INTERNAL_POWER_ERROR
//
#define INTERNAL_POWER_ERROR             ((ULONG)0x000000A0L)

//
// MessageId: PCI_BUS_DRIVER_INTERNAL
//
// MessageText:
//
//  PCI_BUS_DRIVER_INTERNAL
//
#define PCI_BUS_DRIVER_INTERNAL          ((ULONG)0x000000A1L)

//
// MessageId: MEMORY_IMAGE_CORRUPT
//
// MessageText:
//
//  MEMORY_IMAGE_CORRUPT
//
#define MEMORY_IMAGE_CORRUPT             ((ULONG)0x000000A2L)

//
// MessageId: ACPI_DRIVER_INTERNAL
//
// MessageText:
//
//  ACPI_DRIVER_INTERNAL
//
#define ACPI_DRIVER_INTERNAL             ((ULONG)0x000000A3L)

//
// MessageId: CNSS_FILE_SYSTEM_FILTER
//
// MessageText:
//
//  CNSS_FILE_SYSTEM_FILTER
//
#define CNSS_FILE_SYSTEM_FILTER          ((ULONG)0x000000A4L)

//
// MessageId: ACPI_BIOS_ERROR
//
// MessageText:
//
//  ACPI_BIOS_ERROR
//
#define ACPI_BIOS_ERROR                  ((ULONG)0x000000A5L)

//
// MessageId: FP_EMULATION_ERROR
//
// MessageText:
//
//  FP_EMULATION_ERROR
//
#define FP_EMULATION_ERROR               ((ULONG)0x000000A6L)

//
// MessageId: BAD_EXHANDLE
//
// MessageText:
//
//  BAD_EXHANDLE
//
#define BAD_EXHANDLE                     ((ULONG)0x000000A7L)

//
// MessageId: BOOTING_IN_SAFEMODE_MINIMAL
//
// MessageText:
//
//  BOOTING_IN_SAFEMODE_MINIMAL
//
#define BOOTING_IN_SAFEMODE_MINIMAL      ((ULONG)0x000000A8L)

//
// MessageId: BOOTING_IN_SAFEMODE_NETWORK
//
// MessageText:
//
//  BOOTING_IN_SAFEMODE_NETWORK
//
#define BOOTING_IN_SAFEMODE_NETWORK      ((ULONG)0x000000A9L)

//
// MessageId: BOOTING_IN_SAFEMODE_DSREPAIR
//
// MessageText:
//
//  BOOTING_IN_SAFEMODE_DSREPAIR
//
#define BOOTING_IN_SAFEMODE_DSREPAIR     ((ULONG)0x000000AAL)

//
// MessageId: SESSION_HAS_VALID_POOL_ON_EXIT
//
// MessageText:
//
//  SESSION_HAS_VALID_POOL_ON_EXIT
//
#define SESSION_HAS_VALID_POOL_ON_EXIT   ((ULONG)0x000000ABL)

//
// MessageId: HAL_MEMORY_ALLOCATION
//
// MessageText:
//
//  HAL_MEMORY_ALLOCATION
//
#define HAL_MEMORY_ALLOCATION            ((ULONG)0x000000ACL)

//
// MessageId: VIDEO_DRIVER_DEBUG_REPORT_REQUEST
//
// MessageText:
//
//  VIDEO_DRIVER_DEBUG_REPORT_REQUEST
//
#define VIDEO_DRIVER_DEBUG_REPORT_REQUEST ((ULONG)0x400000ADL)

//
// MessageId: BGI_DETECTED_VIOLATION
//
// MessageText:
//
//  BGI_DETECTED_VIOLATION
//
#define BGI_DETECTED_VIOLATION           ((ULONG)0x000000B1L)

//
// MessageId: VIDEO_DRIVER_INIT_FAILURE
//
// MessageText:
//
//  VIDEO_DRIVER_INIT_FAILURE
//
#define VIDEO_DRIVER_INIT_FAILURE        ((ULONG)0x000000B4L)

//
// MessageId: BOOTLOG_LOADED
//
// MessageText:
//
//  BOOTLOG_LOADED
//
#define BOOTLOG_LOADED                   ((ULONG)0x000000B5L)

//
// MessageId: BOOTLOG_NOT_LOADED
//
// MessageText:
//
//  BOOTLOG_NOT_LOADED
//
#define BOOTLOG_NOT_LOADED               ((ULONG)0x000000B6L)

//
// MessageId: BOOTLOG_ENABLED
//
// MessageText:
//
//  BOOTLOG_ENABLED
//
#define BOOTLOG_ENABLED                  ((ULONG)0x000000B7L)

//
// MessageId: ATTEMPTED_SWITCH_FROM_DPC
//
// MessageText:
//
//  ATTEMPTED_SWITCH_FROM_DPC
//
#define ATTEMPTED_SWITCH_FROM_DPC        ((ULONG)0x000000B8L)

//
// MessageId: CHIPSET_DETECTED_ERROR
//
// MessageText:
//
//  CHIPSET_DETECTED_ERROR
//
#define CHIPSET_DETECTED_ERROR           ((ULONG)0x000000B9L)

//
// MessageId: SESSION_HAS_VALID_VIEWS_ON_EXIT
//
// MessageText:
//
//  SESSION_HAS_VALID_VIEWS_ON_EXIT
//
#define SESSION_HAS_VALID_VIEWS_ON_EXIT  ((ULONG)0x000000BAL)

//
// MessageId: NETWORK_BOOT_INITIALIZATION_FAILED
//
// MessageText:
//
//  NETWORK_BOOT_INITIALIZATION_FAILED
//
#define NETWORK_BOOT_INITIALIZATION_FAILED ((ULONG)0x000000BBL)

//
// MessageId: NETWORK_BOOT_DUPLICATE_ADDRESS
//
// MessageText:
//
//  NETWORK_BOOT_DUPLICATE_ADDRESS
//
#define NETWORK_BOOT_DUPLICATE_ADDRESS   ((ULONG)0x000000BCL)

//
// MessageId: INVALID_HIBERNATED_STATE
//
// MessageText:
//
//  INVALID_HIBERNATED_STATE
//
#define INVALID_HIBERNATED_STATE         ((ULONG)0x000000BDL)

//
// MessageId: ATTEMPTED_WRITE_TO_READONLY_MEMORY
//
// MessageText:
//
//  ATTEMPTED_WRITE_TO_READONLY_MEMORY
//
#define ATTEMPTED_WRITE_TO_READONLY_MEMORY ((ULONG)0x000000BEL)

//
// MessageId: MUTEX_ALREADY_OWNED
//
// MessageText:
//
//  MUTEX_ALREADY_OWNED
//
#define MUTEX_ALREADY_OWNED              ((ULONG)0x000000BFL)

//
// MessageId: PCI_CONFIG_SPACE_ACCESS_FAILURE
//
// MessageText:
//
//  PCI_CONFIG_SPACE_ACCESS_FAILURE
//
#define PCI_CONFIG_SPACE_ACCESS_FAILURE  ((ULONG)0x000000C0L)

//
// MessageId: SPECIAL_POOL_DETECTED_MEMORY_CORRUPTION
//
// MessageText:
//
//  SPECIAL_POOL_DETECTED_MEMORY_CORRUPTION
//
#define SPECIAL_POOL_DETECTED_MEMORY_CORRUPTION ((ULONG)0x000000C1L)

//
// MessageId: BAD_POOL_CALLER
//
// MessageText:
//
//  BAD_POOL_CALLER
//
#define BAD_POOL_CALLER                  ((ULONG)0x000000C2L)

//
// MessageId: SYSTEM_IMAGE_BAD_SIGNATURE
//
// MessageText:
//
//  SYSTEM_IMAGE_BAD_SIGNATURE
//
#define SYSTEM_IMAGE_BAD_SIGNATURE       ((ULONG)0x000000C3L)

//
// MessageId: DRIVER_VERIFIER_DETECTED_VIOLATION
//
// MessageText:
//
//  DRIVER_VERIFIER_DETECTED_VIOLATION
//
#define DRIVER_VERIFIER_DETECTED_VIOLATION ((ULONG)0x000000C4L)

//
// MessageId: DRIVER_CORRUPTED_EXPOOL
//
// MessageText:
//
//  DRIVER_CORRUPTED_EXPOOL
//
#define DRIVER_CORRUPTED_EXPOOL          ((ULONG)0x000000C5L)

//
// MessageId: DRIVER_CAUGHT_MODIFYING_FREED_POOL
//
// MessageText:
//
//  DRIVER_CAUGHT_MODIFYING_FREED_POOL
//
#define DRIVER_CAUGHT_MODIFYING_FREED_POOL ((ULONG)0x000000C6L)

//
// MessageId: TIMER_OR_DPC_INVALID
//
// MessageText:
//
//  TIMER_OR_DPC_INVALID
//
#define TIMER_OR_DPC_INVALID             ((ULONG)0x000000C7L)

//
// MessageId: IRQL_UNEXPECTED_VALUE
//
// MessageText:
//
//  IRQL_UNEXPECTED_VALUE
//
#define IRQL_UNEXPECTED_VALUE            ((ULONG)0x000000C8L)

//
// MessageId: DRIVER_VERIFIER_IOMANAGER_VIOLATION
//
// MessageText:
//
//  DRIVER_VERIFIER_IOMANAGER_VIOLATION
//
#define DRIVER_VERIFIER_IOMANAGER_VIOLATION ((ULONG)0x000000C9L)

//
// MessageId: PNP_DETECTED_FATAL_ERROR
//
// MessageText:
//
//  PNP_DETECTED_FATAL_ERROR
//
#define PNP_DETECTED_FATAL_ERROR         ((ULONG)0x000000CAL)

//
// MessageId: DRIVER_LEFT_LOCKED_PAGES_IN_PROCESS
//
// MessageText:
//
//  DRIVER_LEFT_LOCKED_PAGES_IN_PROCESS
//
#define DRIVER_LEFT_LOCKED_PAGES_IN_PROCESS ((ULONG)0x000000CBL)

//
// MessageId: PAGE_FAULT_IN_FREED_SPECIAL_POOL
//
// MessageText:
//
//  PAGE_FAULT_IN_FREED_SPECIAL_POOL
//
#define PAGE_FAULT_IN_FREED_SPECIAL_POOL ((ULONG)0x000000CCL)

//
// MessageId: PAGE_FAULT_BEYOND_END_OF_ALLOCATION
//
// MessageText:
//
//  PAGE_FAULT_BEYOND_END_OF_ALLOCATION
//
#define PAGE_FAULT_BEYOND_END_OF_ALLOCATION ((ULONG)0x000000CDL)

//
// MessageId: DRIVER_UNLOADED_WITHOUT_CANCELLING_PENDING_OPERATIONS
//
// MessageText:
//
//  DRIVER_UNLOADED_WITHOUT_CANCELLING_PENDING_OPERATIONS
//
#define DRIVER_UNLOADED_WITHOUT_CANCELLING_PENDING_OPERATIONS ((ULONG)0x000000CEL)

//
// MessageId: TERMINAL_SERVER_DRIVER_MADE_INCORRECT_MEMORY_REFERENCE
//
// MessageText:
//
//  TERMINAL_SERVER_DRIVER_MADE_INCORRECT_MEMORY_REFERENCE
//
#define TERMINAL_SERVER_DRIVER_MADE_INCORRECT_MEMORY_REFERENCE ((ULONG)0x000000CFL)

//
// MessageId: DRIVER_CORRUPTED_MMPOOL
//
// MessageText:
//
//  DRIVER_CORRUPTED_MMPOOL
//
#define DRIVER_CORRUPTED_MMPOOL          ((ULONG)0x000000D0L)

//
// MessageId: DRIVER_IRQL_NOT_LESS_OR_EQUAL
//
// MessageText:
//
//  DRIVER_IRQL_NOT_LESS_OR_EQUAL
//
#define DRIVER_IRQL_NOT_LESS_OR_EQUAL    ((ULONG)0x000000D1L)

//
// MessageId: BUGCODE_ID_DRIVER
//
// MessageText:
//
//  BUGCODE_ID_DRIVER
//
#define BUGCODE_ID_DRIVER                ((ULONG)0x000000D2L)

//
// MessageId: DRIVER_PORTION_MUST_BE_NONPAGED
//
// MessageText:
//
//  DRIVER_PORTION_MUST_BE_NONPAGED
//
#define DRIVER_PORTION_MUST_BE_NONPAGED  ((ULONG)0x000000D3L)

//
// MessageId: SYSTEM_SCAN_AT_RAISED_IRQL_CAUGHT_IMPROPER_DRIVER_UNLOAD
//
// MessageText:
//
//  SYSTEM_SCAN_AT_RAISED_IRQL_CAUGHT_IMPROPER_DRIVER_UNLOAD
//
#define SYSTEM_SCAN_AT_RAISED_IRQL_CAUGHT_IMPROPER_DRIVER_UNLOAD ((ULONG)0x000000D4L)

//
// MessageId: DRIVER_PAGE_FAULT_IN_FREED_SPECIAL_POOL
//
// MessageText:
//
//  DRIVER_PAGE_FAULT_IN_FREED_SPECIAL_POOL
//
#define DRIVER_PAGE_FAULT_IN_FREED_SPECIAL_POOL ((ULONG)0x000000D5L)

//
// MessageId: DRIVER_PAGE_FAULT_BEYOND_END_OF_ALLOCATION
//
// MessageText:
//
//  DRIVER_PAGE_FAULT_BEYOND_END_OF_ALLOCATION
//
#define DRIVER_PAGE_FAULT_BEYOND_END_OF_ALLOCATION ((ULONG)0x000000D6L)

#define DRIVER_PAGE_FAULT_BEYOND_END_OF_ALLOCATION_M ((ULONG)0x100000D6L)
//
// MessageId: DRIVER_UNMAPPING_INVALID_VIEW
//
// MessageText:
//
//  DRIVER_UNMAPPING_INVALID_VIEW
//
#define DRIVER_UNMAPPING_INVALID_VIEW    ((ULONG)0x000000D7L)

//
// MessageId: DRIVER_USED_EXCESSIVE_PTES
//
// MessageText:
//
//  DRIVER_USED_EXCESSIVE_PTES
//
#define DRIVER_USED_EXCESSIVE_PTES       ((ULONG)0x000000D8L)

//
// MessageId: LOCKED_PAGES_TRACKER_CORRUPTION
//
// MessageText:
//
//  LOCKED_PAGES_TRACKER_CORRUPTION
//
#define LOCKED_PAGES_TRACKER_CORRUPTION  ((ULONG)0x000000D9L)

//
// MessageId: SYSTEM_PTE_MISUSE
//
// MessageText:
//
//  SYSTEM_PTE_MISUSE
//
#define SYSTEM_PTE_MISUSE                ((ULONG)0x000000DAL)

//
// MessageId: DRIVER_CORRUPTED_SYSPTES
//
// MessageText:
//
//  DRIVER_CORRUPTED_SYSPTES
//
#define DRIVER_CORRUPTED_SYSPTES         ((ULONG)0x000000DBL)

//
// MessageId: DRIVER_INVALID_STACK_ACCESS
//
// MessageText:
//
//  DRIVER_INVALID_STACK_ACCESS
//
#define DRIVER_INVALID_STACK_ACCESS      ((ULONG)0x000000DCL)

//
// MessageId: POOL_CORRUPTION_IN_FILE_AREA
//
// MessageText:
//
//  POOL_CORRUPTION_IN_FILE_AREA
//
#define POOL_CORRUPTION_IN_FILE_AREA     ((ULONG)0x000000DEL)

//
// MessageId: IMPERSONATING_WORKER_THREAD
//
// MessageText:
//
//  IMPERSONATING_WORKER_THREAD
//
#define IMPERSONATING_WORKER_THREAD      ((ULONG)0x000000DFL)

//
// MessageId: ACPI_BIOS_FATAL_ERROR
//
// MessageText:
//
//  ACPI_BIOS_FATAL_ERROR
//
#define ACPI_BIOS_FATAL_ERROR            ((ULONG)0x000000E0L)

//
// MessageId: WORKER_THREAD_RETURNED_AT_BAD_IRQL
//
// MessageText:
//
//  WORKER_THREAD_RETURNED_AT_BAD_IRQL
//
#define WORKER_THREAD_RETURNED_AT_BAD_IRQL ((ULONG)0x000000E1L)

//
// MessageId: MANUALLY_INITIATED_CRASH
//
// MessageText:
//
//  MANUALLY_INITIATED_CRASH
//
#define MANUALLY_INITIATED_CRASH         ((ULONG)0x000000E2L)

//
// MessageId: RESOURCE_NOT_OWNED
//
// MessageText:
//
//  RESOURCE_NOT_OWNED
//
#define RESOURCE_NOT_OWNED               ((ULONG)0x000000E3L)

//
// MessageId: WORKER_INVALID
//
// MessageText:
//
//  WORKER_INVALID
//
#define WORKER_INVALID                   ((ULONG)0x000000E4L)

//
// MessageId: POWER_FAILURE_SIMULATE
//
// MessageText:
//
//  POWER_FAILURE_SIMULATE
//
#define POWER_FAILURE_SIMULATE           ((ULONG)0x000000E5L)

//
// MessageId: DRIVER_VERIFIER_DMA_VIOLATION
//
// MessageText:
//
//  DRIVER_VERIFIER_DMA_VIOLATION
//
#define DRIVER_VERIFIER_DMA_VIOLATION    ((ULONG)0x000000E6L)

//
// MessageId: INVALID_FLOATING_POINT_STATE
//
// MessageText:
//
//  INVALID_FLOATING_POINT_STATE
//
#define INVALID_FLOATING_POINT_STATE     ((ULONG)0x000000E7L)

//
// MessageId: INVALID_CANCEL_OF_FILE_OPEN
//
// MessageText:
//
//  INVALID_CANCEL_OF_FILE_OPEN
//
#define INVALID_CANCEL_OF_FILE_OPEN      ((ULONG)0x000000E8L)

//
// MessageId: ACTIVE_EX_WORKER_THREAD_TERMINATION
//
// MessageText:
//
//  ACTIVE_EX_WORKER_THREAD_TERMINATION
//
#define ACTIVE_EX_WORKER_THREAD_TERMINATION ((ULONG)0x000000E9L)

//
// MessageId: THREAD_STUCK_IN_DEVICE_DRIVER
//
// MessageText:
//
//  THREAD_STUCK_IN_DEVICE_DRIVER
//
#define THREAD_STUCK_IN_DEVICE_DRIVER    ((ULONG)0x000000EAL)

#define THREAD_STUCK_IN_DEVICE_DRIVER_M ((ULONG)0x100000EAL)
//
// MessageId: DIRTY_MAPPED_PAGES_CONGESTION
//
// MessageText:
//
//  DIRTY_MAPPED_PAGES_CONGESTION
//
#define DIRTY_MAPPED_PAGES_CONGESTION    ((ULONG)0x000000EBL)

//
// MessageId: SESSION_HAS_VALID_SPECIAL_POOL_ON_EXIT
//
// MessageText:
//
//  SESSION_HAS_VALID_SPECIAL_POOL_ON_EXIT
//
#define SESSION_HAS_VALID_SPECIAL_POOL_ON_EXIT ((ULONG)0x000000ECL)

//
// MessageId: UNMOUNTABLE_BOOT_VOLUME
//
// MessageText:
//
//  UNMOUNTABLE_BOOT_VOLUME
//
#define UNMOUNTABLE_BOOT_VOLUME          ((ULONG)0x000000EDL)

//
// MessageId: CRITICAL_PROCESS_DIED
//
// MessageText:
//
//  CRITICAL_PROCESS_DIED
//
#define CRITICAL_PROCESS_DIED            ((ULONG)0x000000EFL)

//
// MessageId: SCSI_VERIFIER_DETECTED_VIOLATION
//
// MessageText:
//
//  SCSI_VERIFIER_DETECTED_VIOLATION
//
#define SCSI_VERIFIER_DETECTED_VIOLATION ((ULONG)0x000000F1L)

//
// MessageId: HARDWARE_INTERRUPT_STORM
//
// MessageText:
//
//  HARDWARE_INTERRUPT_STORM
//
#define HARDWARE_INTERRUPT_STORM         ((ULONG)0x000000F2L)

//
// MessageId: DISORDERLY_SHUTDOWN
//
// MessageText:
//
//  DISORDERLY_SHUTDOWN
//
#define DISORDERLY_SHUTDOWN              ((ULONG)0x000000F3L)

//
// MessageId: CRITICAL_OBJECT_TERMINATION
//
// MessageText:
//
//  CRITICAL_OBJECT_TERMINATION
//
#define CRITICAL_OBJECT_TERMINATION      ((ULONG)0x000000F4L)

//
// MessageId: FLTMGR_FILE_SYSTEM
//
// MessageText:
//
//  FLTMGR_FILE_SYSTEM
//
#define FLTMGR_FILE_SYSTEM               ((ULONG)0x000000F5L)

//
// MessageId: PCI_VERIFIER_DETECTED_VIOLATION
//
// MessageText:
//
//  PCI_VERIFIER_DETECTED_VIOLATION
//
#define PCI_VERIFIER_DETECTED_VIOLATION  ((ULONG)0x000000F6L)

//
// MessageId: DRIVER_OVERRAN_STACK_BUFFER
//
// MessageText:
//
//  DRIVER_OVERRAN_STACK_BUFFER
//
#define DRIVER_OVERRAN_STACK_BUFFER      ((ULONG)0x000000F7L)

//
// MessageId: RAMDISK_BOOT_INITIALIZATION_FAILED
//
// MessageText:
//
//  RAMDISK_BOOT_INITIALIZATION_FAILED
//
#define RAMDISK_BOOT_INITIALIZATION_FAILED ((ULONG)0x000000F8L)

//
// MessageId: DRIVER_RETURNED_STATUS_REPARSE_FOR_VOLUME_OPEN
//
// MessageText:
//
//  DRIVER_RETURNED_STATUS_REPARSE_FOR_VOLUME_OPEN
//
#define DRIVER_RETURNED_STATUS_REPARSE_FOR_VOLUME_OPEN ((ULONG)0x000000F9L)

//
// MessageId: HTTP_DRIVER_CORRUPTED
//
// MessageText:
//
//  HTTP_DRIVER_CORRUPTED
//
#define HTTP_DRIVER_CORRUPTED            ((ULONG)0x000000FAL)

//
// MessageId: RECURSIVE_MACHINE_CHECK
//
// MessageText:
//
//  RECURSIVE_MACHINE_CHECK
//
#define RECURSIVE_MACHINE_CHECK          ((ULONG)0x000000FBL)

//
// MessageId: ATTEMPTED_EXECUTE_OF_NOEXECUTE_MEMORY
//
// MessageText:
//
//  ATTEMPTED_EXECUTE_OF_NOEXECUTE_MEMORY
//
#define ATTEMPTED_EXECUTE_OF_NOEXECUTE_MEMORY ((ULONG)0x000000FCL)

//
// MessageId: DIRTY_NOWRITE_PAGES_CONGESTION
//
// MessageText:
//
//  DIRTY_NOWRITE_PAGES_CONGESTION
//
#define DIRTY_NOWRITE_PAGES_CONGESTION   ((ULONG)0x000000FDL)

//
// MessageId: BUGCODE_USB_DRIVER
//
// MessageText:
//
//  BUGCODE_USB_DRIVER
//
#define BUGCODE_USB_DRIVER               ((ULONG)0x000000FEL)

//
// MessageId: BC_BLUETOOTH_VERIFIER_FAULT
//
// MessageText:
//
//  BC_BLUETOOTH_VERIFIER_FAULT
//
#define BC_BLUETOOTH_VERIFIER_FAULT      ((ULONG)0x00000BFEL)

//
// MessageId: BC_BTHMINI_VERIFIER_FAULT
//
// MessageText:
//
//  BC_BTHMINI_VERIFIER_FAULT
//
#define BC_BTHMINI_VERIFIER_FAULT        ((ULONG)0x00000BFFL)

//
// MessageId: RESERVE_QUEUE_OVERFLOW
//
// MessageText:
//
//  RESERVE_QUEUE_OVERFLOW
//
#define RESERVE_QUEUE_OVERFLOW           ((ULONG)0x000000FFL)

//
// MessageId: LOADER_BLOCK_MISMATCH
//
// MessageText:
//
//  LOADER_BLOCK_MISMATCH
//
#define LOADER_BLOCK_MISMATCH            ((ULONG)0x00000100L)

//
// MessageId: CLOCK_WATCHDOG_TIMEOUT
//
// MessageText:
//
//  CLOCK_WATCHDOG_TIMEOUT
//
#define CLOCK_WATCHDOG_TIMEOUT           ((ULONG)0x00000101L)

//
// MessageId: DPC_WATCHDOG_TIMEOUT
//
// MessageText:
//
//  DPC_WATCHDOG_TIMEOUT
//
#define DPC_WATCHDOG_TIMEOUT             ((ULONG)0x00000102L)

//
// MessageId: MUP_FILE_SYSTEM
//
// MessageText:
//
//  MUP_FILE_SYSTEM
//
#define MUP_FILE_SYSTEM                  ((ULONG)0x00000103L)

//
// MessageId: AGP_INVALID_ACCESS
//
// MessageText:
//
//  AGP_INVALID_ACCESS
//
#define AGP_INVALID_ACCESS               ((ULONG)0x00000104L)

//
// MessageId: AGP_GART_CORRUPTION
//
// MessageText:
//
//  AGP_GART_CORRUPTION
//
#define AGP_GART_CORRUPTION              ((ULONG)0x00000105L)

//
// MessageId: AGP_ILLEGALLY_REPROGRAMMED
//
// MessageText:
//
//  AGP_ILLEGALLY_REPROGRAMMED
//
#define AGP_ILLEGALLY_REPROGRAMMED       ((ULONG)0x00000106L)

//
// MessageId: KERNEL_EXPAND_STACK_ACTIVE
//
// MessageText:
//
//  KERNEL_EXPAND_STACK_ACTIVE
//
#define KERNEL_EXPAND_STACK_ACTIVE       ((ULONG)0x00000107L)

//
// MessageId: THIRD_PARTY_FILE_SYSTEM_FAILURE
//
// MessageText:
//
//  THIRD_PARTY_FILE_SYSTEM_FAILURE
//
#define THIRD_PARTY_FILE_SYSTEM_FAILURE  ((ULONG)0x00000108L)

//
// MessageId: CRITICAL_STRUCTURE_CORRUPTION
//
// MessageText:
//
//  CRITICAL_STRUCTURE_CORRUPTION
//
#define CRITICAL_STRUCTURE_CORRUPTION    ((ULONG)0x00000109L)

//
// MessageId: APP_TAGGING_INITIALIZATION_FAILED
//
// MessageText:
//
//  APP_TAGGING_INITIALIZATION_FAILED
//
#define APP_TAGGING_INITIALIZATION_FAILED ((ULONG)0x0000010AL)

//
// MessageId: DFSC_FILE_SYSTEM
//
// MessageText:
//
//  DFSC_FILE_SYSTEM
//
#define DFSC_FILE_SYSTEM                 ((ULONG)0x0000010BL)

//
// MessageId: FSRTL_EXTRA_CREATE_PARAMETER_VIOLATION
//
// MessageText:
//
//  FSRTL_EXTRA_CREATE_PARAMETER_VIOLATION
//
#define FSRTL_EXTRA_CREATE_PARAMETER_VIOLATION ((ULONG)0x0000010CL)

//
// MessageId: WDF_VIOLATION
//
// MessageText:
//
//  WDF_VIOLATION
//
#define WDF_VIOLATION                    ((ULONG)0x0000010DL)

//
// MessageId: VIDEO_MEMORY_MANAGEMENT_INTERNAL
//
// MessageText:
//
//  VIDEO_MEMORY_MANAGEMENT_INTERNAL
//
#define VIDEO_MEMORY_MANAGEMENT_INTERNAL ((ULONG)0x0000010EL)

//
// MessageId: DRIVER_INVALID_CRUNTIME_PARAMETER
//
// MessageText:
//
//  DRIVER_INVALID_CRUNTIME_PARAMETER
//
#define DRIVER_INVALID_CRUNTIME_PARAMETER ((ULONG)0x00000110L)

//
// MessageId: RECURSIVE_NMI
//
// MessageText:
//
//  RECURSIVE_NMI
//
#define RECURSIVE_NMI                    ((ULONG)0x00000111L)

//
// MessageId: MSRPC_STATE_VIOLATION
//
// MessageText:
//
//  MSRPC_STATE_VIOLATION
//
#define MSRPC_STATE_VIOLATION            ((ULONG)0x00000112L)

//
// MessageId: VIDEO_DXGKRNL_FATAL_ERROR
//
// MessageText:
//
//  VIDEO_DXGKRNL_FATAL_ERROR
//
#define VIDEO_DXGKRNL_FATAL_ERROR        ((ULONG)0x00000113L)

//
// MessageId: VIDEO_SHADOW_DRIVER_FATAL_ERROR
//
// MessageText:
//
//  VIDEO_SHADOW_DRIVER_FATAL_ERROR
//
#define VIDEO_SHADOW_DRIVER_FATAL_ERROR  ((ULONG)0x00000114L)

//
// MessageId: AGP_INTERNAL
//
// MessageText:
//
//  AGP_INTERNAL
//
#define AGP_INTERNAL                     ((ULONG)0x00000115L)

//
// MessageId: VIDEO_TDR_FAILURE
//
// MessageText:
//
//  VIDEO_TDR_FAILURE
//
#define VIDEO_TDR_FAILURE                ((ULONG)0x00000116L)

//
// MessageId: VIDEO_TDR_TIMEOUT_DETECTED
//
// MessageText:
//
//  VIDEO_TDR_TIMEOUT_DETECTED
//
#define VIDEO_TDR_TIMEOUT_DETECTED       ((ULONG)0x00000117L)

//
// MessageId: NTHV_GUEST_ERROR
//
// MessageText:
//
//  NTHV_GUEST_ERROR
//
#define NTHV_GUEST_ERROR                 ((ULONG)0x00000118L)

//
// MessageId: VIDEO_SCHEDULER_INTERNAL_ERROR
//
// MessageText:
//
//  VIDEO_SCHEDULER_INTERNAL_ERROR
//
#define VIDEO_SCHEDULER_INTERNAL_ERROR   ((ULONG)0x00000119L)

//
// MessageId: EM_INITIALIZATION_ERROR
//
// MessageText:
//
//  EM_INITIALIZATION_ERROR
//
#define EM_INITIALIZATION_ERROR          ((ULONG)0x0000011AL)

//
// MessageId: DRIVER_RETURNED_HOLDING_CANCEL_LOCK
//
// MessageText:
//
//  DRIVER_RETURNED_HOLDING_CANCEL_LOCK
//
#define DRIVER_RETURNED_HOLDING_CANCEL_LOCK ((ULONG)0x0000011BL)

//
// MessageId: ATTEMPTED_WRITE_TO_CM_PROTECTED_STORAGE
//
// MessageText:
//
//  ATTEMPTED_WRITE_TO_CM_PROTECTED_STORAGE
//
#define ATTEMPTED_WRITE_TO_CM_PROTECTED_STORAGE ((ULONG)0x0000011CL)

//
// MessageId: EVENT_TRACING_FATAL_ERROR
//
// MessageText:
//
//  EVENT_TRACING_FATAL_ERROR
//
#define EVENT_TRACING_FATAL_ERROR        ((ULONG)0x0000011DL)

//
// MessageId: TOO_MANY_RECURSIVE_FAULTS
//
// MessageText:
//
//  TOO_MANY_RECURSIVE_FAULTS
//
#define TOO_MANY_RECURSIVE_FAULTS        ((ULONG)0x0000011EL)

//
// MessageId: INVALID_DRIVER_HANDLE
//
// MessageText:
//
//  INVALID_DRIVER_HANDLE
//
#define INVALID_DRIVER_HANDLE            ((ULONG)0x0000011FL)

//
// MessageId: BITLOCKER_FATAL_ERROR
//
// MessageText:
//
//  BITLOCKER_FATAL_ERROR
//
#define BITLOCKER_FATAL_ERROR            ((ULONG)0x00000120L)

//
// MessageId: DRIVER_VIOLATION
//
// MessageText:
//
//  DRIVER_VIOLATION
//
#define DRIVER_VIOLATION                 ((ULONG)0x00000121L)

//
// MessageId: WHEA_INTERNAL_ERROR
//
// MessageText:
//
//  WHEA_INTERNAL_ERROR
//
#define WHEA_INTERNAL_ERROR              ((ULONG)0x00000122L)

//
// MessageId: CRYPTO_SELF_TEST_FAILURE
//
// MessageText:
//
//  CRYPTO_SELF_TEST_FAILURE
//
#define CRYPTO_SELF_TEST_FAILURE         ((ULONG)0x00000123L)

//
// MessageId: WHEA_UNCORRECTABLE_ERROR
//
// MessageText:
//
//  WHEA_UNCORRECTABLE_ERROR
//
#define WHEA_UNCORRECTABLE_ERROR         ((ULONG)0x00000124L)

//
// MessageId: NMR_INVALID_STATE
//
// MessageText:
//
//  NMR_INVALID_STATE
//
#define NMR_INVALID_STATE                ((ULONG)0x00000125L)

//
// MessageId: NETIO_INVALID_POOL_CALLER
//
// MessageText:
//
//  NETIO_INVALID_POOL_CALLER
//
#define NETIO_INVALID_POOL_CALLER        ((ULONG)0x00000126L)

//
// MessageId: PAGE_NOT_ZERO
//
// MessageText:
//
//  PAGE_NOT_ZERO
//
#define PAGE_NOT_ZERO                    ((ULONG)0x00000127L)

//
// MessageId: WORKER_THREAD_RETURNED_WITH_BAD_IO_PRIORITY
//
// MessageText:
//
//  WORKER_THREAD_RETURNED_WITH_BAD_IO_PRIORITY
//
#define WORKER_THREAD_RETURNED_WITH_BAD_IO_PRIORITY ((ULONG)0x00000128L)

//
// MessageId: WORKER_THREAD_RETURNED_WITH_BAD_PAGING_IO_PRIORITY
//
// MessageText:
//
//  WORKER_THREAD_RETURNED_WITH_BAD_PAGING_IO_PRIORITY
//
#define WORKER_THREAD_RETURNED_WITH_BAD_PAGING_IO_PRIORITY ((ULONG)0x00000129L)

//
// MessageId: MUI_NO_VALID_SYSTEM_LANGUAGE
//
// MessageText:
//
//  MUI_NO_VALID_SYSTEM_LANGUAGE
//
#define MUI_NO_VALID_SYSTEM_LANGUAGE     ((ULONG)0x0000012AL)

//
// MessageId: FAULTY_HARDWARE_CORRUPTED_PAGE
//
// MessageText:
//
//  FAULTY_HARDWARE_CORRUPTED_PAGE
//
#define FAULTY_HARDWARE_CORRUPTED_PAGE   ((ULONG)0x0000012BL)

//
// MessageId: EXFAT_FILE_SYSTEM
//
// MessageText:
//
//  EXFAT_FILE_SYSTEM
//
#define EXFAT_FILE_SYSTEM                ((ULONG)0x0000012CL)

//
// MessageId: VOLSNAP_OVERLAPPED_TABLE_ACCESS
//
// MessageText:
//
//  VOLSNAP_OVERLAPPED_TABLE_ACCESS
//
#define VOLSNAP_OVERLAPPED_TABLE_ACCESS  ((ULONG)0x0000012DL)

//
// MessageId: INVALID_MDL_RANGE
//
// MessageText:
//
//  INVALID_MDL_RANGE
//
#define INVALID_MDL_RANGE                ((ULONG)0x0000012EL)

//
// MessageId: VHD_BOOT_INITIALIZATION_FAILED
//
// MessageText:
//
//  VHD_BOOT_INITIALIZATION_FAILED
//
#define VHD_BOOT_INITIALIZATION_FAILED   ((ULONG)0x0000012FL)

//
// MessageId: DYNAMIC_ADD_PROCESSOR_MISMATCH
//
// MessageText:
//
//  DYNAMIC_ADD_PROCESSOR_MISMATCH
//
#define DYNAMIC_ADD_PROCESSOR_MISMATCH   ((ULONG)0x00000130L)

//
// MessageId: INVALID_EXTENDED_PROCESSOR_STATE
//
// MessageText:
//
//  INVALID_EXTENDED_PROCESSOR_STATE
//
#define INVALID_EXTENDED_PROCESSOR_STATE ((ULONG)0x00000131L)

//
// MessageId: RESOURCE_OWNER_POINTER_INVALID
//
// MessageText:
//
//  RESOURCE_OWNER_POINTER_INVALID
//
#define RESOURCE_OWNER_POINTER_INVALID   ((ULONG)0x00000132L)

//
// MessageId: DPC_WATCHDOG_VIOLATION
//
// MessageText:
//
//  DPC_WATCHDOG_VIOLATION
//
#define DPC_WATCHDOG_VIOLATION           ((ULONG)0x00000133L)

//
// MessageId: DRIVE_EXTENDER
//
// MessageText:
//
//  DRIVE_EXTENDER
//
#define DRIVE_EXTENDER                   ((ULONG)0x00000134L)

//
// MessageId: REGISTRY_FILTER_DRIVER_EXCEPTION
//
// MessageText:
//
//  REGISTRY_FILTER_DRIVER_EXCEPTION
//
#define REGISTRY_FILTER_DRIVER_EXCEPTION ((ULONG)0x00000135L)

//
// MessageId: VHD_BOOT_HOST_VOLUME_NOT_ENOUGH_SPACE
//
// MessageText:
//
//  VHD_BOOT_HOST_VOLUME_NOT_ENOUGH_SPACE
//
#define VHD_BOOT_HOST_VOLUME_NOT_ENOUGH_SPACE ((ULONG)0x00000136L)

//
// MessageId: WIN32K_HANDLE_MANAGER
//
// MessageText:
//
//  WIN32K_HANDLE_MANAGER
//
#define WIN32K_HANDLE_MANAGER            ((ULONG)0x00000137L)

//
// MessageId: GPIO_CONTROLLER_DRIVER_ERROR
//
// MessageText:
//
//  GPIO_CONTROLLER_DRIVER_ERROR
//
#define GPIO_CONTROLLER_DRIVER_ERROR     ((ULONG)0x00000138L)

//
// MessageId: KERNEL_SECURITY_CHECK_FAILURE
//
// MessageText:
//
//  KERNEL_SECURITY_CHECK_FAILURE
//
#define KERNEL_SECURITY_CHECK_FAILURE    ((ULONG)0x00000139L)

//
// MessageId: KERNEL_MODE_HEAP_CORRUPTION
//
// MessageText:
//
//  KERNEL_MODE_HEAP_CORRUPTION
//
#define KERNEL_MODE_HEAP_CORRUPTION      ((ULONG)0x0000013AL)

//
// MessageId: PASSIVE_INTERRUPT_ERROR
//
// MessageText:
//
//  PASSIVE_INTERRUPT_ERROR
//
#define PASSIVE_INTERRUPT_ERROR          ((ULONG)0x0000013BL)

//
// MessageId: INVALID_IO_BOOST_STATE
//
// MessageText:
//
//  INVALID_IO_BOOST_STATE
//
#define INVALID_IO_BOOST_STATE           ((ULONG)0x0000013CL)

//
// MessageId: CRITICAL_INITIALIZATION_FAILURE
//
// MessageText:
//
//  CRITICAL_INITIALIZATION_FAILURE
//
#define CRITICAL_INITIALIZATION_FAILURE  ((ULONG)0x0000013DL)

//
// MessageId: STORAGE_DEVICE_ABNORMALITY_DETECTED
//
// MessageText:
//
//  STORAGE_DEVICE_ABNORMALITY_DETECTED
//
#define STORAGE_DEVICE_ABNORMALITY_DETECTED ((ULONG)0x00000140L)

//
// MessageId: VIDEO_ENGINE_TIMEOUT_DETECTED
//
// MessageText:
//
//  VIDEO_ENGINE_TIMEOUT_DETECTED
//
#define VIDEO_ENGINE_TIMEOUT_DETECTED    ((ULONG)0x00000141L)

//
// MessageId: VIDEO_TDR_APPLICATION_BLOCKED
//
// MessageText:
//
//  VIDEO_TDR_APPLICATION_BLOCKED
//
#define VIDEO_TDR_APPLICATION_BLOCKED    ((ULONG)0x00000142L)

//
// MessageId: PROCESSOR_DRIVER_INTERNAL
//
// MessageText:
//
//  PROCESSOR_DRIVER_INTERNAL
//
#define PROCESSOR_DRIVER_INTERNAL        ((ULONG)0x00000143L)

//
// MessageId: BUGCODE_USB3_DRIVER
//
// MessageText:
//
//  BUGCODE_USB3_DRIVER
//
#define BUGCODE_USB3_DRIVER              ((ULONG)0x00000144L)

//
// MessageId: SECURE_BOOT_VIOLATION
//
// MessageText:
//
//  SECURE_BOOT_VIOLATION
//
#define SECURE_BOOT_VIOLATION            ((ULONG)0x00000145L)

//
// MessageId: NDIS_NET_BUFFER_LIST_INFO_ILLEGALLY_TRANSFERRED
//
// MessageText:
//
//  NDIS_NET_BUFFER_LIST_INFO_ILLEGALLY_TRANSFERRED
//
#define NDIS_NET_BUFFER_LIST_INFO_ILLEGALLY_TRANSFERRED ((ULONG)0x00000146L)

//
// MessageId: ABNORMAL_RESET_DETECTED
//
// MessageText:
//
//  ABNORMAL_RESET_DETECTED
//
#define ABNORMAL_RESET_DETECTED          ((ULONG)0x00000147L)

//
// MessageId: IO_OBJECT_INVALID
//
// MessageText:
//
//  IO_OBJECT_INVALID
//
#define IO_OBJECT_INVALID                ((ULONG)0x00000148L)

//
// MessageId: REFS_FILE_SYSTEM
//
// MessageText:
//
//  REFS_FILE_SYSTEM
//
#define REFS_FILE_SYSTEM                 ((ULONG)0x00000149L)

//
// MessageId: KERNEL_WMI_INTERNAL
//
// MessageText:
//
//  KERNEL_WMI_INTERNAL
//
#define KERNEL_WMI_INTERNAL              ((ULONG)0x0000014AL)

//
// MessageId: SOC_SUBSYSTEM_FAILURE
//
// MessageText:
//
//  SOC_SUBSYSTEM_FAILURE
//
#define SOC_SUBSYSTEM_FAILURE            ((ULONG)0x0000014BL)

//
// MessageId: FATAL_ABNORMAL_RESET_ERROR
//
// MessageText:
//
//  FATAL_ABNORMAL_RESET_ERROR
//
#define FATAL_ABNORMAL_RESET_ERROR       ((ULONG)0x0000014CL)

//
// MessageId: EXCEPTION_SCOPE_INVALID
//
// MessageText:
//
//  EXCEPTION_SCOPE_INVALID
//
#define EXCEPTION_SCOPE_INVALID          ((ULONG)0x0000014DL)

//
// MessageId: SOC_CRITICAL_DEVICE_REMOVED
//
// MessageText:
//
//  SOC_CRITICAL_DEVICE_REMOVED
//
#define SOC_CRITICAL_DEVICE_REMOVED      ((ULONG)0x0000014EL)

//
// MessageId: PDC_WATCHDOG_TIMEOUT
//
// MessageText:
//
//  PDC_WATCHDOG_TIMEOUT
//
#define PDC_WATCHDOG_TIMEOUT             ((ULONG)0x0000014FL)

//
// MessageId: TCPIP_AOAC_NIC_ACTIVE_REFERENCE_LEAK
//
// MessageText:
//
//  TCPIP_AOAC_NIC_ACTIVE_REFERENCE_LEAK
//
#define TCPIP_AOAC_NIC_ACTIVE_REFERENCE_LEAK ((ULONG)0x00000150L)

//
// MessageId: UNSUPPORTED_INSTRUCTION_MODE
//
// MessageText:
//
//  UNSUPPORTED_INSTRUCTION_MODE
//
#define UNSUPPORTED_INSTRUCTION_MODE     ((ULONG)0x00000151L)

//
// MessageId: INVALID_PUSH_LOCK_FLAGS
//
// MessageText:
//
//  INVALID_PUSH_LOCK_FLAGS
//
#define INVALID_PUSH_LOCK_FLAGS          ((ULONG)0x00000152L)

//
// MessageId: KERNEL_LOCK_ENTRY_LEAKED_ON_THREAD_TERMINATION
//
// MessageText:
//
//  KERNEL_LOCK_ENTRY_LEAKED_ON_THREAD_TERMINATION
//
#define KERNEL_LOCK_ENTRY_LEAKED_ON_THREAD_TERMINATION ((ULONG)0x00000153L)

//
// MessageId: UNEXPECTED_STORE_EXCEPTION
//
// MessageText:
//
//  UNEXPECTED_STORE_EXCEPTION
//
#define UNEXPECTED_STORE_EXCEPTION       ((ULONG)0x00000154L)

//
// MessageId: OS_DATA_TAMPERING
//
// MessageText:
//
//  OS_DATA_TAMPERING
//
#define OS_DATA_TAMPERING                ((ULONG)0x00000155L)

//
// MessageId: WINSOCK_DETECTED_HUNG_CLOSESOCKET_LIVEDUMP
//
// MessageText:
//
//  WINSOCK_DETECTED_HUNG_CLOSESOCKET_LIVEDUMP
//
#define WINSOCK_DETECTED_HUNG_CLOSESOCKET_LIVEDUMP ((ULONG)0x00000156L)

//
// MessageId: KERNEL_THREAD_PRIORITY_FLOOR_VIOLATION
//
// MessageText:
//
//  KERNEL_THREAD_PRIORITY_FLOOR_VIOLATION
//
#define KERNEL_THREAD_PRIORITY_FLOOR_VIOLATION ((ULONG)0x00000157L)

//
// MessageId: ILLEGAL_IOMMU_PAGE_FAULT
//
// MessageText:
//
//  ILLEGAL_IOMMU_PAGE_FAULT
//
#define ILLEGAL_IOMMU_PAGE_FAULT         ((ULONG)0x00000158L)

//
// MessageId: HAL_ILLEGAL_IOMMU_PAGE_FAULT
//
// MessageText:
//
//  HAL_ILLEGAL_IOMMU_PAGE_FAULT
//
#define HAL_ILLEGAL_IOMMU_PAGE_FAULT     ((ULONG)0x00000159L)

//
// MessageId: SDBUS_INTERNAL_ERROR
//
// MessageText:
//
//  SDBUS_INTERNAL_ERROR
//
#define SDBUS_INTERNAL_ERROR             ((ULONG)0x0000015AL)

//
// MessageId: WORKER_THREAD_RETURNED_WITH_SYSTEM_PAGE_PRIORITY_ACTIVE
//
// MessageText:
//
//  WORKER_THREAD_RETURNED_WITH_SYSTEM_PAGE_PRIORITY_ACTIVE
//
#define WORKER_THREAD_RETURNED_WITH_SYSTEM_PAGE_PRIORITY_ACTIVE ((ULONG)0x0000015BL)

//
// MessageId: PDC_WATCHDOG_TIMEOUT_LIVEDUMP
//
// MessageText:
//
//  PDC_WATCHDOG_TIMEOUT_LIVEDUMP
//
#define PDC_WATCHDOG_TIMEOUT_LIVEDUMP    ((ULONG)0x0000015CL)

//
// MessageId: SOC_SUBSYSTEM_FAILURE_LIVEDUMP
//
// MessageText:
//
//  SOC_SUBSYSTEM_FAILURE_LIVEDUMP
//
#define SOC_SUBSYSTEM_FAILURE_LIVEDUMP   ((ULONG)0x0000015DL)

//
// MessageId: BUGCODE_NDIS_DRIVER_LIVE_DUMP
//
// MessageText:
//
//  BUGCODE_NDIS_DRIVER_LIVE_DUMP
//
#define BUGCODE_NDIS_DRIVER_LIVE_DUMP    ((ULONG)0x0000015EL)

//
// MessageId: CONNECTED_STANDBY_WATCHDOG_TIMEOUT_LIVEDUMP
//
// MessageText:
//
//  CONNECTED_STANDBY_WATCHDOG_TIMEOUT_LIVEDUMP
//
#define CONNECTED_STANDBY_WATCHDOG_TIMEOUT_LIVEDUMP ((ULONG)0x0000015FL)

//
// MessageId: WIN32K_ATOMIC_CHECK_FAILURE
//
// MessageText:
//
//  WIN32K_ATOMIC_CHECK_FAILURE
//
#define WIN32K_ATOMIC_CHECK_FAILURE      ((ULONG)0x00000160L)

//
// MessageId: LIVE_SYSTEM_DUMP
//
// MessageText:
//
//  LIVE_SYSTEM_DUMP
//
#define LIVE_SYSTEM_DUMP                 ((ULONG)0x00000161L)

//
// MessageId: KERNEL_AUTO_BOOST_INVALID_LOCK_RELEASE
//
// MessageText:
//
//  KERNEL_AUTO_BOOST_INVALID_LOCK_RELEASE
//
#define KERNEL_AUTO_BOOST_INVALID_LOCK_RELEASE ((ULONG)0x00000162L)

//
// MessageId: WORKER_THREAD_TEST_CONDITION
//
// MessageText:
//
//  WORKER_THREAD_TEST_CONDITION
//
#define WORKER_THREAD_TEST_CONDITION     ((ULONG)0x00000163L)

//
// MessageId: CLUSTER_CSV_STATUS_IO_TIMEOUT_LIVEDUMP
//
// MessageText:
//
//  CLUSTER_CSV_STATUS_IO_TIMEOUT_LIVEDUMP
//
#define CLUSTER_CSV_STATUS_IO_TIMEOUT_LIVEDUMP ((ULONG)0x00000164L)

//
// MessageId: CLUSTER_CSV_SNAPSHOT_DEVICE_INFO_TIMEOUT_LIVEDUMP
//
// MessageText:
//
//  CLUSTER_CSV_SNAPSHOT_DEVICE_INFO_TIMEOUT_LIVEDUMP
//
#define CLUSTER_CSV_SNAPSHOT_DEVICE_INFO_TIMEOUT_LIVEDUMP ((ULONG)0x00000166L)

//
// MessageId: CLUSTER_CSV_STATE_TRANSITION_TIMEOUT_LIVEDUMP
//
// MessageText:
//
//  CLUSTER_CSV_STATE_TRANSITION_TIMEOUT_LIVEDUMP
//
#define CLUSTER_CSV_STATE_TRANSITION_TIMEOUT_LIVEDUMP ((ULONG)0x00000167L)

//
// MessageId: CLUSTER_CSV_VOLUME_ARRIVAL_LIVEDUMP
//
// MessageText:
//
//  CLUSTER_CSV_VOLUME_ARRIVAL_LIVEDUMP
//
#define CLUSTER_CSV_VOLUME_ARRIVAL_LIVEDUMP ((ULONG)0x00000168L)

//
// MessageId: CLUSTER_CSV_VOLUME_REMOVAL_LIVEDUMP
//
// MessageText:
//
//  CLUSTER_CSV_VOLUME_REMOVAL_LIVEDUMP
//
#define CLUSTER_CSV_VOLUME_REMOVAL_LIVEDUMP ((ULONG)0x00000169L)

//
// MessageId: CLUSTER_CSV_STATE_TRANSITION_INTERVAL_TIMEOUT_LIVEDUMP
//
// MessageText:
//
//  CLUSTER_CSV_STATE_TRANSITION_INTERVAL_TIMEOUT_LIVEDUMP
//
#define CLUSTER_CSV_STATE_TRANSITION_INTERVAL_TIMEOUT_LIVEDUMP ((ULONG)0x00000174L)

//
// MessageId: WIN32K_PRERELEASE_FREE_ASSERT
//
// MessageText:
//
//  WIN32K_PRERELEASE_FREE_ASSERT
//
#define WIN32K_PRERELEASE_FREE_ASSERT    ((ULONG)0x00000187L)

//
// MessageId: XBOX_360_SYSTEM_CRASH
//
// MessageText:
//
//  XBOX_360_SYSTEM_CRASH
//
#define XBOX_360_SYSTEM_CRASH            ((ULONG)0x00000360L)

//
// MessageId: XBOX_360_SYSTEM_CRASH_RESERVED
//
// MessageText:
//
//  XBOX_360_SYSTEM_CRASH_RESERVED
//
#define XBOX_360_SYSTEM_CRASH_RESERVED   ((ULONG)0x00000420L)

//
// MessageId: HYPERVISOR_ERROR
//
// MessageText:
//
//  HYPERVISOR_ERROR
//
#define HYPERVISOR_ERROR                 ((ULONG)0x00020001L)

#define WINLOGON_FATAL_ERROR ((ULONG)0xC000021AL)
#define MANUALLY_INITIATED_CRASH1 ((ULONG)0xDEADDEAD)
#endif // _BUGCODES_
